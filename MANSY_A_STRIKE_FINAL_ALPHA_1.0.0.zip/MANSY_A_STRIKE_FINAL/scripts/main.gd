extends Node3D

# MANSY A STRIKE - mobile FPS offline/LAN prototype
# Godot 4.x / Landscape 16:9 / GL Compatibility
# Bomb Mission is intentionally OFFLINE ONLY.

const NET_PORT := 27891
const DISCOVERY_PORT := 27901
const MAX_TEAM_SIZE := 5
const PLAYER_SPEED := 5.5
const MATCH_LIMIT_SECONDS := 600.0
const BOMB_PLANT_TIME := 4.0
const BOMB_DEFUSE_TIME := 3.5
const BOMB_TIME := 40.0

var WEAPONS := {
    "ASSAULT RIFLE": {"damage": 34, "mag": 30, "reload": 1.25, "fire_delay": 0.105, "range": 90.0, "spread": 0.010},
    "SMG": {"damage": 24, "mag": 36, "reload": 1.15, "fire_delay": 0.075, "range": 65.0, "spread": 0.020},
    "SHOTGUN": {"damage": 18, "pellets": 8, "mag": 8, "reload": 1.45, "fire_delay": 0.75, "range": 35.0, "spread": 0.080},
    "SNIPER": {"damage": 95, "mag": 5, "reload": 1.8, "fire_delay": 1.0, "range": 150.0, "spread": 0.003},
    "PISTOL": {"damage": 30, "mag": 15, "reload": 0.9, "fire_delay": 0.22, "range": 60.0, "spread": 0.018},
    "GRENADE": {"damage": 70, "mag": 1, "reload": 1.0, "fire_delay": 1.0, "range": 28.0, "spread": 0.0}
}
var weapon_order := ["ASSAULT RIFLE", "SMG", "SHOTGUN", "SNIPER", "PISTOL", "GRENADE"]

var menu_layer: CanvasLayer
var hud_layer: CanvasLayer
var menu_root: Control
var hud_root: Control
var panel_root: Control
var score_label: Label
var ammo_label: Label
var status_label: Label
var killfeed_label: Label
var crosshair: Label
var objective_label: Label
var health_bar: ProgressBar
var armor_bar: ProgressBar
var joystick: Control
var look_area: Control
var fire_button: Button
var reload_button: Button
var jump_button: Button
var crouch_button: Button
var weapon_buttons: Array[Button] = []
var bomb_button: Button
var room_status: Label
var ip_edit: LineEdit
var mode_box: OptionButton
var team_box: OptionButton
var ai_box: OptionButton
var weapon_box: OptionButton
var menu_tab_label: Label
var profile_label: Label
var settings_panel: Control

var match_started := false
var match_mode := "offline"
var match_type := "tdm"
var team_size := 5
var ai_difficulty := 1
var score_blue := 0
var score_red := 0
var kills := 0
var deaths := 0
var assists := 0
var time_left := MATCH_LIMIT_SECONDS
var player: CharacterBody3D
var camera: Camera3D
var player_health := 100
var player_armor := 100
var player_yaw := 0.0
var player_pitch := -0.05
var crouched := false
var reloading := false
var fire_cooldown := 0.0
var current_weapon := "ASSAULT RIFLE"
var ammo_by_weapon: Dictionary = {}
var bots: Array[CharacterBody3D] = []
var bot_team: Dictionary = {}
var bot_health: Dictionary = {}
var bot_armor: Dictionary = {}
var bot_fire_timer: Dictionary = {}
var bot_strafe_timer: Dictionary = {}
var bot_target: Dictionary = {}
var bot_dead_timer: Dictionary = {}
var remote_players: Dictionary = {}
var remote_health: Dictionary = {}
var peer_team: Dictionary = {}
var peer := ENetMultiplayerPeer.new()
var discovery_socket := PacketPeerUDP.new()
var discovery_timer := 0.0
var lan_is_host := false
var server_started := false
var rng := RandomNumberGenerator.new()
var bomb_carrier := false
var bomb_planted := false
var bomb_site := ""
var bomb_timer := 0.0
var bomb_action_timer := 0.0
var bomb_action := ""
var bomb_sites: Dictionary = {"A": Vector3(-7, 0.15, -7), "B": Vector3(0, 0.15, 0), "C": Vector3(7, 0.15, 7)}
var bomb_site_nodes: Dictionary = {}
var bomb_button_held := false
var match_round := 1
var target_score := 30
var profile_kills := 0
var profile_deaths := 0
var profile_matches := 0
var sensitivity := 1.0
var music_volume := 0.8
var graphics_quality := 1
var profile_path := "user://mansy_profile.cfg"
var training_targets: Array[CharacterBody3D] = []
var killfeed_lines: Array[String] = []
var last_message := ""
var lan_match_started := false
var round_wins_blue := 0
var round_wins_red := 0
var match_paused := false

func _ready() -> void:
    rng.randomize()
    _load_profile()
    _build_world()
    _build_menu()
    _build_hud()
    _set_menu_visible(true)
    multiplayer.peer_connected.connect(_on_peer_connected)
    multiplayer.peer_disconnected.connect(_on_peer_disconnected)
    multiplayer.connected_to_server.connect(_on_connected_to_server)

func _process(delta: float) -> void:
    if match_paused:
        return
    fire_cooldown = maxf(0.0, fire_cooldown - delta)
    if not match_started:
        _process_discovery(delta)
        return
    if match_mode != "offline" and match_type == "bomb":
        match_type = "tdm"
    if time_left > 0.0:
        time_left = maxf(0.0, time_left - delta)
    if time_left <= 0.0:
        _end_match("TIME UP")
        return
    if match_mode == "offline":
        _update_bots(delta)
    _update_bomb(delta)
    _update_hud()
    if match_mode == "lan":
        _network_tick(delta)
    if Input.is_action_pressed("fire") and fire_button == null:
        _fire()

func _physics_process(delta: float) -> void:
    if match_paused:
        return
    if not match_started or player == null:
        return
    _move_player(delta)

func _input(event: InputEvent) -> void:
    if not match_started:
        return
    if event is InputEventKey and event.pressed and not event.echo:
        if event.keycode == KEY_R:
            _reload()
        elif event.keycode == KEY_SPACE:
            _jump()
        elif event.keycode == KEY_C:
            _toggle_crouch()
        elif event.keycode == KEY_1:
            _equip_weapon(0)
        elif event.keycode == KEY_2:
            _equip_weapon(1)
        elif event.keycode == KEY_3:
            _equip_weapon(2)
        elif event.keycode == KEY_4:
            _equip_weapon(3)
        elif event.keycode == KEY_5:
            _equip_weapon(4)
        elif event.keycode == KEY_6:
            _equip_weapon(5)
        elif event.keycode == KEY_ESCAPE:
            _toggle_pause()
        elif event.keycode == KEY_F:
            _bomb_action_pressed()
    elif event is InputEventMouseMotion and Input.mouse_mode == Input.MOUSE_MODE_CAPTURED:
        player_yaw -= event.relative.x * 0.003 * sensitivity
        player_pitch = clampf(player_pitch - event.relative.y * 0.0025 * sensitivity, -1.15, 1.15)

func _build_world() -> void:
    var env := WorldEnvironment.new()
    var environment := Environment.new()
    environment.background_mode = Environment.BG_COLOR
    environment.background_color = Color("10151c")
    environment.ambient_light_source = Environment.AMBIENT_SOURCE_COLOR
    environment.ambient_light_color = Color("7d8794")
    environment.ambient_light_energy = 0.7
    env.environment = environment
    add_child(env)

    var light := DirectionalLight3D.new()
    light.rotation_degrees = Vector3(-55.0, -25.0, 0.0)
    light.light_energy = 1.25
    add_child(light)

    _make_box("Floor", Vector3(0, -0.5, 0), Vector3(34, 1, 34), Color("252e37"))
    _make_box("NorthWall", Vector3(0, 2, -17), Vector3(34, 4, 1), Color("37424d"))
    _make_box("SouthWall", Vector3(0, 2, 17), Vector3(34, 4, 1), Color("37424d"))
    _make_box("WestWall", Vector3(-17, 2, 0), Vector3(1, 4, 34), Color("37424d"))
    _make_box("EastWall", Vector3(17, 2, 0), Vector3(1, 4, 34), Color("37424d"))

    var cover_positions := [
        Vector3(-7, 1, -5), Vector3(7, 1, -5), Vector3(-7, 1, 5), Vector3(7, 1, 5),
        Vector3(-2.5, 1, 0), Vector3(2.5, 1, 0), Vector3(0, 1, -7), Vector3(0, 1, 7),
        Vector3(-11, 1, 0), Vector3(11, 1, 0)
    ]
    for p in cover_positions:
        _make_box("Cover", p, Vector3(3.0, 2.0, 1.4), Color("46535f"))

func _make_box(n: String, pos: Vector3, size: Vector3, color: Color) -> void:
    var body := StaticBody3D.new()
    body.name = n
    body.position = pos
    var mesh := MeshInstance3D.new()
    var box := BoxMesh.new()
    box.size = size
    mesh.mesh = box
    var mat := StandardMaterial3D.new()
    mat.albedo_color = color
    mesh.material_override = mat
    body.add_child(mesh)
    var collision := CollisionShape3D.new()
    var shape := BoxShape3D.new()
    shape.size = size
    collision.shape = shape
    body.add_child(collision)
    add_child(body)

func _build_menu() -> void:
    menu_layer = CanvasLayer.new()
    add_child(menu_layer)
    menu_root = Control.new()
    menu_root.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
    menu_layer.add_child(menu_root)

    var background := TextureRect.new()
    background.texture = load("res://assets/mansy_mainmenu_wide.png")
    background.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
    background.expand_mode = TextureRect.EXPAND_IGNORE_SIZE
    background.stretch_mode = TextureRect.STRETCH_KEEP_ASPECT_COVERED
    background.mouse_filter = Control.MOUSE_FILTER_IGNORE
    menu_root.add_child(background)

    var shade := ColorRect.new()
    shade.color = Color(0.0, 0.0, 0.0, 0.45)
    shade.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
    shade.mouse_filter = Control.MOUSE_FILTER_IGNORE
    menu_root.add_child(shade)

    var title := Label.new()
    title.text = "MANSY A STRIKE"
    title.position = Vector2(38, 24)
    title.size = Vector2(560, 60)
    title.add_theme_font_size_override("font_size", 42)
    title.add_theme_color_override("font_color", Color.WHITE)
    menu_root.add_child(title)

    var subtitle := Label.new()
    subtitle.text = "MOBILE FPS  •  OFFLINE  •  HOTSPOT/LAN  •  1v1—5v5"
    subtitle.position = Vector2(42, 78)
    subtitle.size = Vector2(700, 30)
    subtitle.add_theme_font_size_override("font_size", 15)
    subtitle.add_theme_color_override("font_color", Color("ffd23f"))
    menu_root.add_child(subtitle)

    var panel := ColorRect.new()
    panel.color = Color(0.02, 0.04, 0.06, 0.93)
    panel.position = Vector2(30, 300)
    panel.size = Vector2(1220, 390)
    menu_root.add_child(panel)

    var play_title := Label.new()
    play_title.text = "PLAY"
    play_title.position = Vector2(55, 320)
    play_title.size = Vector2(160, 32)
    play_title.add_theme_font_size_override("font_size", 19)
    menu_root.add_child(play_title)

    var offline := _menu_button("OFFLINE VS AI", Vector2(55, 360), Vector2(260, 55))
    offline.pressed.connect(func(): _select_mode("offline"))
    menu_root.add_child(offline)
    var lan := _menu_button("HOTSPOT / LAN", Vector2(325, 360), Vector2(260, 55))
    lan.pressed.connect(func(): _select_mode("lan"))
    menu_root.add_child(lan)
    var training := _menu_button("TRAINING", Vector2(595, 360), Vector2(190, 55))
    training.pressed.connect(func(): _select_mode("training"))
    menu_root.add_child(training)

    var type_title := Label.new()
    type_title.text = "MATCH TYPE"
    type_title.position = Vector2(55, 435)
    type_title.size = Vector2(200, 30)
    menu_root.add_child(type_title)
    mode_box = OptionButton.new()
    mode_box.position = Vector2(55, 470)
    mode_box.size = Vector2(260, 52)
    mode_box.add_item("TEAM DEATHMATCH")
    mode_box.add_item("DEATHMATCH")
    mode_box.add_item("BOMB MISSION • A/B/C • OFFLINE ONLY")
    mode_box.item_selected.connect(_on_match_type_selected)
    menu_root.add_child(mode_box)

    var team_title := Label.new()
    team_title.text = "TEAM SIZE"
    team_title.position = Vector2(335, 435)
    team_title.size = Vector2(160, 30)
    menu_root.add_child(team_title)
    team_box = OptionButton.new()
    for n in range(1, MAX_TEAM_SIZE + 1):
        team_box.add_item(str(n) + "v" + str(n))
    team_box.selected = 4
    team_box.position = Vector2(335, 470)
    team_box.size = Vector2(170, 52)
    team_box.item_selected.connect(func(index): team_size = index + 1)
    menu_root.add_child(team_box)

    var ai_title := Label.new()
    ai_title.text = "AI DIFFICULTY"
    ai_title.position = Vector2(525, 435)
    ai_title.size = Vector2(180, 30)
    menu_root.add_child(ai_title)
    ai_box = OptionButton.new()
    for label in ["EASY", "NORMAL", "HARD", "ELITE"]:
        ai_box.add_item(label)
    ai_box.selected = 1
    ai_box.position = Vector2(525, 470)
    ai_box.size = Vector2(170, 52)
    ai_box.item_selected.connect(func(index): ai_difficulty = index)
    menu_root.add_child(ai_box)

    var loadout_title := Label.new()
    loadout_title.text = "STARTING LOADOUT"
    loadout_title.position = Vector2(715, 435)
    loadout_title.size = Vector2(220, 30)
    menu_root.add_child(loadout_title)
    weapon_box = OptionButton.new()
    for w in weapon_order:
        weapon_box.add_item(w)
    weapon_box.position = Vector2(715, 470)
    weapon_box.size = Vector2(200, 52)
    weapon_box.selected = 0
    weapon_box.item_selected.connect(func(index): current_weapon = weapon_order[index])
    menu_root.add_child(weapon_box)

    var start := _menu_button("START MATCH", Vector2(930, 470), Vector2(285, 68))
    start.add_theme_font_size_override("font_size", 22)
    start.pressed.connect(_start_selected_match)
    menu_root.add_child(start)

    var stats := _menu_button("PROFILE / STATS", Vector2(930, 545), Vector2(140, 50))
    stats.pressed.connect(_show_profile)
    menu_root.add_child(stats)
    var settings := _menu_button("SETTINGS", Vector2(1075, 545), Vector2(140, 50))
    settings.pressed.connect(_show_settings)
    menu_root.add_child(settings)

    ip_edit = LineEdit.new()
    ip_edit.placeholder_text = "Host IP e.g. 192.168.43.1"
    ip_edit.text = "192.168.43.1"
    ip_edit.position = Vector2(55, 545)
    ip_edit.size = Vector2(300, 48)
    menu_root.add_child(ip_edit)
    var host := _menu_button("CREATE ROOM", Vector2(365, 545), Vector2(155, 48))
    host.pressed.connect(_host_lan)
    menu_root.add_child(host)
    var join := _menu_button("JOIN ROOM", Vector2(525, 545), Vector2(145, 48))
    join.pressed.connect(_join_lan)
    menu_root.add_child(join)

    room_status = Label.new()
    room_status.position = Vector2(55, 600)
    room_status.size = Vector2(850, 65)
    room_status.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
    room_status.add_theme_font_size_override("font_size", 14)
    menu_root.add_child(room_status)

    profile_label = Label.new()
    profile_label.position = Vector2(935, 605)
    profile_label.size = Vector2(280, 55)
    profile_label.add_theme_font_size_override("font_size", 12)
    menu_root.add_child(profile_label)
    _update_profile_label()
    _select_mode("offline")

func _menu_button(text_value: String, pos: Vector2, size: Vector2) -> Button:
    var b := Button.new()
    b.text = text_value
    b.position = pos
    b.size = size
    b.add_theme_font_size_override("font_size", 16)
    return b

func _on_match_type_selected(index: int) -> void:
    if index == 2 and match_mode != "offline" and match_mode != "training":
        mode_box.selected = 0
        match_type = "tdm"
        room_status.text = "Bomb Mission is OFFLINE ONLY. It is not available in Hotspot/LAN."
        return
    match_type = ["tdm", "dm", "bomb"][index]
    if match_type == "bomb":
        room_status.text = "BOMB MISSION: BLUE attacks. Plant at A/B/C in 4s; RED defuses in 3.5s."
    elif match_type == "dm":
        room_status.text = "DEATHMATCH: every bot is an enemy. First to the target score wins."
    else:
        room_status.text = "TEAM DEATHMATCH: BLUE vs RED."

func _build_hud() -> void:
    hud_layer = CanvasLayer.new()
    add_child(hud_layer)
    hud_root = Control.new()
    hud_root.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
    hud_root.mouse_filter = Control.MOUSE_FILTER_IGNORE
    hud_layer.add_child(hud_root)

    score_label = _hud_label(Vector2(20, 14), Vector2(600, 38), 20)
    ammo_label = _hud_label(Vector2(20, 52), Vector2(420, 38), 18)
    status_label = _hud_label(Vector2(20, 88), Vector2(650, 40), 15)
    objective_label = _hud_label(Vector2(440, 18), Vector2(400, 65), 17)
    objective_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
    killfeed_label = _hud_label(Vector2(950, 20), Vector2(300, 120), 13)
    killfeed_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_RIGHT

    health_bar = ProgressBar.new()
    health_bar.position = Vector2(20, 640)
    health_bar.size = Vector2(230, 20)
    health_bar.max_value = 100
    hud_root.add_child(health_bar)
    armor_bar = ProgressBar.new()
    armor_bar.position = Vector2(20, 665)
    armor_bar.size = Vector2(230, 20)
    armor_bar.max_value = 100
    hud_root.add_child(armor_bar)

    crosshair = Label.new()
    crosshair.text = "+"
    crosshair.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
    crosshair.vertical_alignment = VERTICAL_ALIGNMENT_CENTER
    crosshair.position = Vector2(610, 325)
    crosshair.size = Vector2(60, 60)
    crosshair.add_theme_font_size_override("font_size", 32)
    hud_root.add_child(crosshair)

    _create_mobile_controls()
    hud_root.visible = false

func _hud_label(pos: Vector2, size: Vector2, font: int) -> Label:
    var l := Label.new()
    l.position = pos
    l.size = size
    l.add_theme_font_size_override("font_size", font)
    hud_root.add_child(l)
    return l

func _create_mobile_controls() -> void:
    joystick = _make_joystick()
    hud_root.add_child(joystick)
    look_area = Control.new()
    look_area.position = Vector2(300, 70)
    look_area.size = Vector2(650, 510)
    look_area.mouse_filter = Control.MOUSE_FILTER_PASS
    look_area.gui_input.connect(_on_look_input)
    hud_root.add_child(look_area)

    fire_button = _action_button("FIRE", Vector2(1060, 485), Vector2(150, 80))
    fire_button.button_down.connect(_fire)
    fire_button.button_down.connect(func(): fire_button_held = true)
    fire_button.button_up.connect(func(): fire_button_held = false)
    hud_root.add_child(fire_button)
    reload_button = _action_button("RELOAD", Vector2(900, 585), Vector2(130, 60))
    reload_button.pressed.connect(_reload)
    hud_root.add_child(reload_button)
    jump_button = _action_button("JUMP", Vector2(1060, 585), Vector2(130, 60))
    jump_button.pressed.connect(_jump)
    hud_root.add_child(jump_button)
    crouch_button = _action_button("CROUCH", Vector2(900, 515), Vector2(130, 60))
    crouch_button.pressed.connect(_toggle_crouch)
    hud_root.add_child(crouch_button)
    bomb_button = _action_button("BOMB", Vector2(740, 585), Vector2(130, 60))
    bomb_button.pressed.connect(_bomb_action_pressed)
    hud_root.add_child(bomb_button)

    var next_weapon := _action_button("NEXT", Vector2(740, 515), Vector2(130, 60))
    next_weapon.pressed.connect(_next_weapon)
    hud_root.add_child(next_weapon)
    var pause_button := _action_button("PAUSE", Vector2(900, 445), Vector2(130, 55))
    pause_button.pressed.connect(_toggle_pause)
    hud_root.add_child(pause_button)

func _action_button(text_value: String, pos: Vector2, size: Vector2) -> Button:
    var b := Button.new()
    b.text = text_value
    b.position = pos
    b.size = size
    b.add_theme_font_size_override("font_size", 16)
    return b

func _make_joystick() -> Control:
    var root := Control.new()
    root.name = "VirtualJoystick"
    root.position = Vector2(25, 455)
    root.size = Vector2(260, 220)
    var base := ColorRect.new()
    base.color = Color("ffffff26")
    base.position = Vector2(20, 20)
    base.size = Vector2(180, 180)
    root.add_child(base)
    var knob := ColorRect.new()
    knob.name = "Knob"
    knob.color = Color("ffffff80")
    knob.position = Vector2(75, 75)
    knob.size = Vector2(70, 70)
    root.add_child(knob)
    root.gui_input.connect(func(event): _joystick_input(root, knob, event))
    return root

var joystick_vector := Vector2.ZERO
var look_touch_id := -1
var fire_button_held := false

func _joystick_input(root: Control, knob: Control, event: InputEvent) -> void:
    if event is InputEventScreenTouch:
        if event.pressed:
            var local := event.position - root.global_position
            var v := (local - Vector2(110, 110)).limit_length(80.0)
            joystick_vector = v / 80.0
            knob.position = Vector2(75, 75) + v
        else:
            joystick_vector = Vector2.ZERO
            knob.position = Vector2(75, 75)
    elif event is InputEventScreenDrag:
        var local2 := event.position - root.global_position
        var v2 := (local2 - Vector2(110, 110)).limit_length(80.0)
        joystick_vector = v2 / 80.0
        knob.position = Vector2(75, 75) + v2

func _on_look_input(event: InputEvent) -> void:
    if event is InputEventScreenTouch:
        if event.pressed:
            look_touch_id = event.index
        elif event.index == look_touch_id:
            look_touch_id = -1
    elif event is InputEventScreenDrag and event.index == look_touch_id:
        player_yaw -= event.relative.x * 0.006 * sensitivity
        player_pitch = clampf(player_pitch - event.relative.y * 0.004 * sensitivity, -1.15, 1.15)
        if player:
            player.rotation.y = player_yaw
            camera.rotation.x = player_pitch

func _select_mode(mode: String) -> void:
    match_mode = mode
    if mode == "lan" and match_type == "bomb":
        match_type = "tdm"
        mode_box.selected = 0
    if mode == "training":
        match_type = "training"
        mode_box.disabled = true
        team_box.disabled = true
        ai_box.disabled = true
        room_status.text = "TRAINING: targets, unlimited practice and weapon testing."
    else:
        mode_box.disabled = false
        team_box.disabled = false
        ai_box.disabled = false
        if mode == "offline":
            room_status.text = "OFFLINE: TDM / Deathmatch / Bomb Mission."
        else:
            room_status.text = "HOTSPOT/LAN: TDM or Deathmatch only. Bomb Mission is OFFLINE ONLY."

func _start_selected_match() -> void:
    if match_mode == "training":
        _start_training()
        return
    if match_mode == "lan" and match_type == "bomb":
        match_type = "tdm"
        mode_box.selected = 0
    _start_match()

func _start_match() -> void:
    if match_mode == "lan" and not server_started:
        room_status.text = "Create Room or Join Room first for Hotspot/LAN."
        return
    if match_mode == "lan":
        if not lan_is_host:
            room_status.text = "Only the host starts the LAN match."
            return
        _start_lan_match.rpc()
        return
    _reset_match()
    _spawn_local_player(1, 0)
    if match_mode == "offline":
        _spawn_offline_bots()
    _set_menu_visible(false)
    profile_matches += 1
    _save_profile()

@rpc("authority", "reliable", "call_local")
func _start_lan_match() -> void:
    if match_mode != "lan":
        return
    _reset_match()
    var my_id := multiplayer.get_unique_id()
    var my_team := int(peer_team.get(my_id, 0))
    _spawn_local_player(my_id, my_team)
    _set_menu_visible(false)
    profile_matches += 1
    _save_profile()

func _start_training() -> void:
    match_mode = "training"
    match_type = "training"
    _reset_match()
    _spawn_local_player(1, 0)
    _spawn_training_targets()
    _set_menu_visible(false)
    room_status.text = ""

func _reset_match() -> void:
    match_started = true
    match_paused = false
    score_blue = 0
    score_red = 0
    kills = 0
    deaths = 0
    assists = 0
    time_left = MATCH_LIMIT_SECONDS
    player_health = 100
    player_armor = 100
    reloading = false
    fire_cooldown = 0.0
    match_round = 1
    round_wins_blue = 0
    round_wins_red = 0
    lan_match_started = match_mode == "lan"
    target_score = 30
    bomb_carrier = match_type == "bomb"
    bomb_planted = false
    bomb_site = ""
    bomb_timer = 0.0
    bomb_action_timer = 0.0
    bomb_action = ""
    _clear_bomb_sites()
    if match_type == "bomb":
        _create_bomb_sites()
    for b in bots:
        if is_instance_valid(b): b.queue_free()
    bots.clear(); bot_team.clear(); bot_health.clear(); bot_armor.clear(); bot_fire_timer.clear(); bot_strafe_timer.clear(); bot_target.clear(); bot_dead_timer.clear()
    for t in training_targets:
        if is_instance_valid(t): t.queue_free()
    training_targets.clear()
    _reset_ammo()
    killfeed_lines.clear()
    _update_hud()
    hud_root.visible = true

func _reset_ammo() -> void:
    ammo_by_weapon.clear()
    for w in weapon_order:
        ammo_by_weapon[w] = int(WEAPONS[w]["mag"])
    ammo_by_weapon["GRENADE"] = 1
    if not WEAPONS.has(current_weapon): current_weapon = "ASSAULT RIFLE"

func _spawn_local_player(peer_id: int, team: int) -> void:
    if player and is_instance_valid(player): player.queue_free()
    player = CharacterBody3D.new()
    player.name = "Player_%s" % peer_id
    player.position = _spawn_point(team, peer_id)
    var collision := CollisionShape3D.new()
    var capsule := CapsuleShape3D.new(); capsule.radius = 0.45; capsule.height = 1.8
    collision.shape = capsule; player.add_child(collision)
    var mesh := MeshInstance3D.new()
    var capsule_mesh := CapsuleMesh.new(); capsule_mesh.radius = 0.45; capsule_mesh.height = 1.8
    mesh.mesh = capsule_mesh
    var mat := StandardMaterial3D.new(); mat.albedo_color = Color("4aa3ff") if team == 0 else Color("ff4a55")
    mesh.material_override = mat; player.add_child(mesh)
    camera = Camera3D.new(); camera.position = Vector3(0, 0.55, 0); camera.current = true; player.add_child(camera)
    add_child(player)
    player_yaw = 0.0 if team == 0 else PI
    Input.mouse_mode = Input.MOUSE_MODE_VISIBLE

func _spawn_offline_bots() -> void:
    if match_type == "dm":
        for i in range(team_size * 2 - 1): _spawn_bot(100 + i, 1)
        return
    for i in range(1, team_size): _spawn_bot(i, 0)
    for i in range(team_size): _spawn_bot(100 + i, 1)

func _spawn_training_targets() -> void:
    for i in range(8):
        var target := CharacterBody3D.new()
        target.name = "TrainingTarget_%d" % i
        target.position = Vector3(-10 + float(i % 4) * 6.5, 1.0, -7 + float(i / 4) * 12.0)
        var collision := CollisionShape3D.new()
        var capsule := CapsuleShape3D.new(); capsule.radius = 0.45; capsule.height = 1.8
        collision.shape = capsule; target.add_child(collision)
        var mesh := MeshInstance3D.new(); var cm := CapsuleMesh.new(); cm.radius = 0.45; cm.height = 1.8; mesh.mesh = cm
        var mat := StandardMaterial3D.new(); mat.albedo_color = Color("e8b83e"); mesh.material_override = mat; target.add_child(mesh)
        add_child(target); training_targets.append(target)

func _spawn_bot(id_value: int, team: int) -> void:
    var bot := CharacterBody3D.new()
    bot.name = "Bot_%s" % id_value
    bot.position = _spawn_point(team, id_value)
    var collision := CollisionShape3D.new(); var capsule := CapsuleShape3D.new(); capsule.radius = 0.45; capsule.height = 1.8; collision.shape = capsule; bot.add_child(collision)
    var mesh := MeshInstance3D.new(); var capsule_mesh := CapsuleMesh.new(); capsule_mesh.radius = 0.45; capsule_mesh.height = 1.8; mesh.mesh = capsule_mesh
    var mat := StandardMaterial3D.new(); mat.albedo_color = Color("4aa3ff") if team == 0 else Color("ff4a55"); mesh.material_override = mat; bot.add_child(mesh)
    add_child(bot); bots.append(bot)
    bot_team[bot] = team; bot_health[bot] = 100; bot_armor[bot] = 50; bot_fire_timer[bot] = rng.randf_range(0.2, 1.0); bot_strafe_timer[bot] = rng.randf_range(0.0, 2.0); bot_target[bot] = 0.0

func _spawn_point(team: int, seed_value: int) -> Vector3:
    var side := -1.0 if team == 0 else 1.0
    var z := float((abs(seed_value) * 7) % 13 - 6)
    return Vector3(side * 9.0, 1.2, z)

func _create_bomb_sites() -> void:
    for site_name in bomb_sites.keys():
        var marker := MeshInstance3D.new()
        var cylinder := CylinderMesh.new(); cylinder.top_radius = 1.5; cylinder.bottom_radius = 1.5; cylinder.height = 0.18; marker.mesh = cylinder
        var mat := StandardMaterial3D.new(); mat.albedo_color = Color("3e8cff"); marker.material_override = mat; marker.position = bomb_sites[site_name]; add_child(marker)
        var label := Label3D.new(); label.text = "SITE " + str(site_name); label.position = bomb_sites[site_name] + Vector3(0, 1.5, 0); label.font_size = 48; add_child(label)
        bomb_site_nodes[site_name] = [marker, label]

func _clear_bomb_sites() -> void:
    for value in bomb_site_nodes.values():
        for node in value:
            if is_instance_valid(node): node.queue_free()
    bomb_site_nodes.clear()

func _nearest_bomb_site() -> String:
    if player == null: return ""
    var best := ""; var best_dist := INF
    for site_name in bomb_sites.keys():
        var d := player.global_position.distance_squared_to(bomb_sites[site_name])
        if d < best_dist: best_dist = d; best = str(site_name)
    return best if best_dist <= 9.0 else ""

func _bomb_action_pressed() -> void:
    if match_mode != "offline" or match_type != "bomb" or player == null: return
    if bomb_action != "": return
    var site := _nearest_bomb_site()
    if bomb_planted:
        # The local player is BLUE (attacker), so only RED AI can defuse locally.
        return
    if bomb_carrier and not site.is_empty():
        bomb_action = "plant"; bomb_action_timer = BOMB_PLANT_TIME; bomb_site = site

func _update_bomb(delta: float) -> void:
    if match_type != "bomb" or match_mode != "offline" or player == null: return
    if bomb_action != "":
        bomb_action_timer -= delta
        if bomb_action_timer <= 0.0:
            if bomb_action == "plant" and bomb_carrier:
                bomb_planted = true; bomb_timer = BOMB_TIME; bomb_carrier = false
                _add_killfeed("BLUE planted at SITE %s" % bomb_site)
            elif bomb_action == "defuse" and bomb_planted:
                _add_killfeed("RED defused the bomb"); _end_bomb_round("RED DEFUSED — ROUND LOST")
            bomb_action = ""
    if bomb_planted:
        bomb_timer -= delta
        if bomb_timer <= 0.0:
            score_blue += 1; round_wins_blue += 1; _end_bomb_round("BOMB EXPLODED — BLUE WINS")
        for bot in bots:
            if is_instance_valid(bot) and bot_team.get(bot, 1) == 1:
                _move_bot_toward(bot, bomb_sites[bomb_site], BOT_SPEED())
                if bot.global_position.distance_to(bomb_sites[bomb_site]) < 3.0 and rng.randf() < delta * (0.35 + ai_difficulty * 0.15):
                    bomb_planted = false; round_wins_red += 1; _add_killfeed("RED defused the bomb"); _end_bomb_round("RED DEFUSED — ROUND LOST")

func _end_bomb_round(message: String) -> void:
    bomb_action = ""; bomb_action_timer = 0.0; bomb_planted = false; bomb_carrier = true
    status_label.text = message
    match_round += 1
    if round_wins_blue >= 5 or round_wins_red >= 5:
        _end_match("BOMB MATCH COMPLETE • " + message)
        return
    await get_tree().create_timer(1.5).timeout
    if match_started: _reset_bomb_round()

func _reset_bomb_round() -> void:
    bomb_planted = false; bomb_site = ""; bomb_timer = 0.0; bomb_action = ""; bomb_action_timer = 0.0; bomb_carrier = true
    if player: player.global_position = Vector3(-9, 1.2, 0)
    for bot in bots:
        if is_instance_valid(bot): bot.global_position = _spawn_point(bot_team.get(bot, 1), rng.randi_range(1, 20))

func BOT_SPEED() -> float:
    return 3.1 + float(ai_difficulty) * 0.65

func _update_bots(delta: float) -> void:
    if player == null: return
    for bot in bots:
        if not is_instance_valid(bot): continue
        var team: int = int(bot_team.get(bot, 1))
        bot_fire_timer[bot] = float(bot_fire_timer.get(bot, 0.0)) - delta
        bot_strafe_timer[bot] = float(bot_strafe_timer.get(bot, 0.0)) - delta
        var target := _find_bot_target(bot, team)
        if target == null: continue
        var target_pos := target.global_position
        var dist := bot.global_position.distance_to(target_pos)
        var ideal_range := 9.0 + float(ai_difficulty) * 4.0
        if match_type == "bomb" and bomb_planted and team == 1:
            target_pos = bomb_sites[bomb_site]
            dist = bot.global_position.distance_to(target_pos)
        if dist > ideal_range:
            _move_bot_toward(bot, target_pos, BOT_SPEED())
        else:
            bot.velocity = Vector3.ZERO
            bot.look_at(Vector3(target_pos.x, bot.global_position.y, target_pos.z), Vector3.UP)
            if bot_strafe_timer[bot] <= 0.0:
                bot_strafe_timer[bot] = rng.randf_range(0.7, 1.8)
                var side := bot.global_transform.basis.x * (1.0 if rng.randf() > 0.5 else -1.0)
                bot.velocity = side.normalized() * (1.0 + ai_difficulty * 0.25)
                bot.move_and_slide()
            if bot_fire_timer[bot] <= 0.0 and dist < 55.0:
                var reaction := maxf(0.22, 1.15 - float(ai_difficulty) * 0.22)
                bot_fire_timer[bot] = reaction + rng.randf_range(0.0, 0.3)
                _bot_fire(bot, target)

func _find_bot_target(bot: CharacterBody3D, team: int) -> Node3D:
    if match_type == "dm":
        if player != null: return player
        return null
    if team == 1 and player != null: return player
    var best: Node3D = null; var best_dist := INF
    for other in bots:
        if not is_instance_valid(other) or other == bot: continue
        var other_team := int(bot_team.get(other, 1))
        if other_team == team: continue
        var d := bot.global_position.distance_squared_to(other.global_position)
        if d < best_dist: best_dist = d; best = other
    if team == 0 and player != null:
        var pd := bot.global_position.distance_squared_to(player.global_position)
        if pd < best_dist: best = player
    return best

func _move_bot_toward(bot: CharacterBody3D, target_pos: Vector3, speed: float) -> void:
    var dir := target_pos - bot.global_position; dir.y = 0.0
    if dir.length() > 1.5:
        bot.velocity = dir.normalized() * speed
        bot.move_and_slide()
        bot.look_at(Vector3(target_pos.x, bot.global_position.y, target_pos.z), Vector3.UP)
    else:
        bot.velocity = Vector3.ZERO

func _bot_fire(bot: CharacterBody3D, target: Node3D) -> void:
    if target == null: return
    var accuracy := 0.35 + float(ai_difficulty) * 0.15
    if match_type == "dm": accuracy += 0.05
    if rng.randf() > accuracy: return
    var damage := 5 + ai_difficulty * 3
    if target == player:
        _damage_player(damage, bot)
    elif target in bots:
        _damage_bot(target, damage, bot)

func _damage_player(amount: int, attacker: Node3D = null) -> void:
    var armor_damage := min(player_armor, int(amount * 0.55))
    player_armor -= armor_damage
    player_health -= amount - int(armor_damage * 0.35)
    if player_health <= 0:
        deaths += 1; profile_deaths += 1
        score_red += 1
        _add_killfeed("YOU were eliminated")
        player_health = 100; player_armor = 100
        player.global_position = _spawn_point(0, rng.randi_range(1, 20))
        if match_type == "bomb": bomb_carrier = true; bomb_planted = false; bomb_site = ""
        _save_profile()
        _check_score_end()

func _damage_bot(target: CharacterBody3D, amount: int, attacker: Node3D) -> void:
    if not is_instance_valid(target): return
    var armor := int(bot_armor.get(target, 0)); var absorbed := min(armor, int(amount * 0.5)); armor -= absorbed
    var hp := int(bot_health.get(target, 100)) - (amount - int(absorbed * 0.35)); bot_armor[target] = armor; bot_health[target] = hp
    if hp <= 0:
        var victim_team := int(bot_team.get(target, 1)); var attacker_team := 0 if attacker == player else int(bot_team.get(attacker, 0))
        if match_type == "dm" or victim_team != attacker_team:
            if attacker == player: kills += 1; profile_kills += 1; score_blue += 1
            elif attacker in bots and attacker_team == 0: score_blue += 1
            else: score_red += 1
        _add_killfeed("YOU eliminated %s" % target.name if attacker == player else "%s eliminated %s" % [attacker.name, target.name])
        bot_health[target] = 100; bot_armor[target] = 50; target.global_position = _spawn_point(victim_team, rng.randi_range(1, 20))
        if match_type == "bomb" and victim_team == 0: bomb_carrier = true; bomb_planted = false; bomb_site = ""
        _check_score_end()
        _save_profile()

func _check_score_end() -> void:
    if match_type == "dm" and score_blue >= target_score: _end_match("TARGET SCORE REACHED")
    elif match_type == "tdm" and score_blue >= target_score: _end_match("BLUE REACHED TARGET SCORE")
    elif match_type == "tdm" and score_red >= target_score: _end_match("RED REACHED TARGET SCORE")

func _move_player(delta: float) -> void:
    if player == null: return
    var input_vec := joystick_vector
    if input_vec.length() < 0.05: input_vec = Input.get_vector("move_left", "move_right", "move_forward", "move_back")
    var basis := player.global_transform.basis
    var dir := (basis.x * input_vec.x + -basis.z * input_vec.y); dir.y = 0.0
    var speed := PLAYER_SPEED * (0.62 if crouched else 1.0)
    if dir.length() > 0.01:
        player.velocity.x = dir.normalized().x * speed; player.velocity.z = dir.normalized().z * speed
    else:
        player.velocity.x = move_toward(player.velocity.x, 0.0, speed * delta * 6.0); player.velocity.z = move_toward(player.velocity.z, 0.0, speed * delta * 6.0)
    if not player.is_on_floor(): player.velocity.y -= 18.0 * delta
    player.move_and_slide(); player.rotation.y = player_yaw; camera.rotation.x = player_pitch
    if fire_button_held and fire_cooldown <= 0.0: _fire()

func _fire() -> void:
    if not match_started or reloading or camera == null or fire_cooldown > 0.0: return
    var weapon: Dictionary = WEAPONS[current_weapon]
    var ammo := int(ammo_by_weapon.get(current_weapon, 0))
    if current_weapon == "GRENADE":
        if ammo <= 0: return
        ammo_by_weapon[current_weapon] = 0
        fire_cooldown = float(weapon["fire_delay"])
        _grenade_attack()
        return
    if ammo <= 0:
        _reload(); return
    ammo_by_weapon[current_weapon] = ammo - 1
    fire_cooldown = float(weapon["fire_delay"])
    var pellets := int(weapon.get("pellets", 1))
    for p in range(pellets): _hitscan(float(weapon["damage"]), float(weapon["range"]), float(weapon["spread"]))
    if match_mode == "lan" and multiplayer.has_multiplayer_peer():
        var shot_dir := -camera.global_transform.basis.z
        _request_lan_shot.rpc_id(1, camera.global_position, shot_dir, float(weapon["damage"]), float(weapon["range"]))

func _hitscan(damage: float, range_value: float, spread: float) -> void:
    var from := camera.global_position
    var forward := -camera.global_transform.basis.z
    forward = (forward + Vector3(rng.randf_range(-spread, spread), rng.randf_range(-spread, spread), rng.randf_range(-spread, spread))).normalized()
    var to := from + forward * range_value
    var query := PhysicsRayQueryParameters3D.create(from, to); query.exclude = [player]
    var hit := get_world_3d().direct_space_state.intersect_ray(query)
    if not hit.has("collider"): return
    var target = hit["collider"]
    if target in bots: _damage_bot(target, int(damage), player)
    elif target in training_targets:
        _add_killfeed("TARGET HIT • %d DAMAGE" % int(damage))
        target.global_position = Vector3(0, -50, 0)
        await get_tree().create_timer(1.0).timeout
        if is_instance_valid(target): target.global_position = Vector3(rng.randf_range(-12, 12), 1.0, rng.randf_range(-9, 9))

func _grenade_attack() -> void:
    var origin := camera.global_position
    for bot in bots:
        if is_instance_valid(bot) and bot.global_position.distance_to(origin) <= 8.0:
            _damage_bot(bot, 70, player)
    _add_killfeed("GRENADE THROWN")

@rpc("any_peer", "unreliable", "call_remote")
func _request_lan_shot(origin: Vector3, direction: Vector3, damage: float, range_value: float) -> void:
    if not lan_is_host or not match_started:
        return
    var sender := multiplayer.get_remote_sender_id()
    if sender == 0:
        return
    var shooter := player if sender == multiplayer.get_unique_id() else remote_players.get(sender, null)
    if shooter == null:
        return
    var query := PhysicsRayQueryParameters3D.create(origin, origin + direction.normalized() * range_value)
    query.exclude = [shooter]
    var hit := get_world_3d().direct_space_state.intersect_ray(query)
    if not hit.has("collider"):
        return
    var target = hit["collider"]
    if target == player and sender != multiplayer.get_unique_id():
        _apply_lan_damage.rpc(multiplayer.get_unique_id(), int(damage), sender)
    elif target in remote_players.values():
        var victim_id := -1
        for rid in remote_players.keys():
            if remote_players[rid] == target:
                victim_id = int(rid); break
        if victim_id > 0 and victim_id != sender:
            _apply_lan_damage.rpc(victim_id, int(damage), sender)

@rpc("authority", "reliable", "call_local")
func _apply_lan_damage(victim_id: int, amount: int, attacker_id: int) -> void:
    if not match_started:
        return
    if victim_id == multiplayer.get_unique_id():
        _damage_player(amount, null)
        return
    if not remote_players.has(victim_id):
        return
    var hp := int(remote_health.get(victim_id, 100)) - amount
    remote_health[victim_id] = hp
    if hp <= 0:
        var victim_team := int(peer_team.get(victim_id, 1))
        var attacker_team := int(peer_team.get(attacker_id, 0))
        if victim_team != attacker_team:
            if attacker_id == multiplayer.get_unique_id():
                kills += 1; profile_kills += 1; score_blue += 1
            elif attacker_team == 0:
                score_blue += 1
            else:
                score_red += 1
            _check_score_end()
        remote_health[victim_id] = 100
        var body: CharacterBody3D = remote_players[victim_id]
        body.global_position = _spawn_point(victim_team, victim_id)
        _save_profile()

func _reload() -> void:
    if reloading or current_weapon == "GRENADE": return
    var max_ammo := int(WEAPONS[current_weapon]["mag"])
    if int(ammo_by_weapon.get(current_weapon, 0)) >= max_ammo: return
    reloading = true
    status_label.text = "RELOADING %s..." % current_weapon
    await get_tree().create_timer(float(WEAPONS[current_weapon]["reload"])).timeout
    if match_started:
        ammo_by_weapon[current_weapon] = max_ammo
        reloading = false

func _equip_weapon(index: int) -> void:
    if index < 0 or index >= weapon_order.size(): return
    current_weapon = weapon_order[index]
    reloading = false

func _next_weapon() -> void:
    var index := weapon_order.find(current_weapon)
    _equip_weapon((index + 1) % weapon_order.size())

func _jump() -> void:
    if player and player.is_on_floor(): player.velocity.y = 7.0

func _toggle_crouch() -> void:
    crouched = not crouched

func _update_hud() -> void:
    if not hud_root or not hud_root.visible: return
    if bomb_button: bomb_button.visible = match_type == "bomb" and match_mode == "offline"
    var mode_text := "OFFLINE" if match_mode == "offline" else ("TRAINING" if match_mode == "training" else "LAN")
    score_label.text = "%s   BLUE %02d - %02d RED   %02d:%02d" % [mode_text, score_blue, score_red, int(time_left) / 60, int(time_left) % 60]
    var current_ammo := int(ammo_by_weapon.get(current_weapon, 0))
    var max_ammo := int(WEAPONS.get(current_weapon, {"mag": 1})["mag"])
    ammo_label.text = "%s   %02d/%02d   %s" % [current_weapon, current_ammo, max_ammo, "RELOADING" if reloading else ""]
    health_bar.value = player_health; armor_bar.value = player_armor
    if match_type == "bomb":
        var bomb_state := "CARRY BOMB" if bomb_carrier and not bomb_planted else ("BOMB %s • %02d" % [bomb_site, maxf(0.0, bomb_timer)]) if bomb_planted else "DEFEND / ATTACK SITES"
        if bomb_action != "": bomb_state += " • %s %.1fs" % [bomb_action.to_upper(), maxf(0.0, bomb_action_timer)]
        objective_label.text = "BOMB MISSION\n%s" % bomb_state
    elif match_type == "training":
        objective_label.text = "TRAINING RANGE\nTEST WEAPONS"
    else:
        objective_label.text = "%s\nTARGET %d" % ["DEATHMATCH" if match_type == "dm" else "TEAM DEATHMATCH", target_score]
    status_label.text = "TEAM %dv%d • AI %s • K/D %d/%d" % [team_size, team_size, ["EASY", "NORMAL", "HARD", "ELITE"][ai_difficulty], kills, deaths]
    killfeed_label.text = "\n".join(killfeed_lines)

func _add_killfeed(text_value: String) -> void:
    killfeed_lines.push_front(text_value)
    while killfeed_lines.size() > 5: killfeed_lines.pop_back()
    last_message = text_value

func _set_menu_visible(value: bool) -> void:
    menu_root.visible = value
    hud_root.visible = not value
    if value:
        match_started = false
        fire_button_held = false
        Input.mouse_mode = Input.MOUSE_MODE_VISIBLE
        _update_profile_label()

func _end_match(reason: String) -> void:
    if not match_started: return
    match_started = false
    match_paused = false
    _clear_bomb_sites()
    _set_menu_visible(true)
    room_status.text = "MATCH OVER • %s • BLUE %d : %d RED • K/D %d/%d" % [reason, score_blue, score_red, kills, deaths]
    _save_profile()

func _toggle_pause() -> void:
    if not match_started: return
    match_paused = not match_paused
    hud_root.visible = not match_paused
    if match_paused:
        status_label.text = "PAUSED — PRESS ESC TO RESUME"

func _host_lan() -> void:
    match_mode = "lan"
    if match_type == "bomb": match_type = "tdm"; mode_box.selected = 0
    lan_is_host = true; peer = ENetMultiplayerPeer.new()
    var err := peer.create_server(NET_PORT, MAX_TEAM_SIZE * 2 - 1)
    if err != OK:
        room_status.text = "Could not create LAN room. Error: " + str(err); return
    multiplayer.multiplayer_peer = peer; server_started = true; peer_team[1] = 0
    room_status.text = "ROOM CREATED • Host IP appears on hotspot network. Press START MATCH."

func _join_lan() -> void:
    match_mode = "lan"
    if match_type == "bomb": match_type = "tdm"; mode_box.selected = 0
    lan_is_host = false
    var ip := ip_edit.text.strip_edges()
    if ip.is_empty(): room_status.text = "Enter the hotspot host IP first."; return
    peer = ENetMultiplayerPeer.new()
    var err := peer.create_client(ip, NET_PORT)
    if err != OK: room_status.text = "Could not connect: " + str(err); return
    multiplayer.multiplayer_peer = peer; server_started = true; room_status.text = "CONNECTING TO HOST..."

func _on_peer_connected(id: int) -> void:
    if not lan_is_host: return
    var assigned_team := 0 if peer_team.values().count(0) <= peer_team.values().count(1) else 1
    peer_team[id] = assigned_team
    _sync_lobby.rpc_id(id, team_size, peer_team)
    _spawn_remote.rpc(id, assigned_team)
    for existing_id in peer_team.keys():
        if int(existing_id) != id: _spawn_remote.rpc_id(id, int(existing_id), int(peer_team[existing_id]))
    if match_started:
        _start_lan_match.rpc_id(id)

func _on_connected_to_server() -> void:
    if match_mode != "lan": return
    var my_id := multiplayer.get_unique_id()
    var team: int = int(peer_team.get(my_id, 1))
    _spawn_local_player(my_id, team)
    room_status.text = "CONNECTED • WAIT FOR HOST START"

@rpc("authority", "reliable")
func _sync_lobby(new_team_size: int, teams: Dictionary) -> void:
    team_size = clampi(new_team_size, 1, MAX_TEAM_SIZE); peer_team = teams.duplicate()
    var my_id := multiplayer.get_unique_id(); var team: int = int(peer_team.get(my_id, 1))
    if player == null: _spawn_local_player(my_id, team)

@rpc("authority", "reliable", "call_local")
func _spawn_remote(id: int, team: int) -> void:
    if id == multiplayer.get_unique_id() or remote_players.has(id): return
    var body := CharacterBody3D.new(); body.name = "Remote_%s" % id; body.position = _spawn_point(team, id)
    var collision := CollisionShape3D.new()
    var capsule := CapsuleShape3D.new(); capsule.radius = 0.45; capsule.height = 1.8
    collision.shape = capsule; body.add_child(collision)
    var mesh := MeshInstance3D.new(); var cm := CapsuleMesh.new(); cm.radius = 0.45; cm.height = 1.8; mesh.mesh = cm
    var mat := StandardMaterial3D.new(); mat.albedo_color = Color("4aa3ff") if team == 0 else Color("ff4a55"); mesh.material_override = mat; body.add_child(mesh); add_child(body); remote_players[id] = body

func _on_peer_disconnected(id: int) -> void:
    if remote_players.has(id):
        var body: Node = remote_players[id]
        if is_instance_valid(body): body.queue_free()
        remote_players.erase(id)
    remote_health.erase(id)
    peer_team.erase(id)

func _network_tick(delta: float) -> void:
    if not match_started or player == null or not multiplayer.has_multiplayer_peer(): return
    _net_transform.rpc(player.global_position, player.rotation.y)
    if lan_is_host:
        discovery_timer += delta
        if discovery_timer >= 1.0:
            discovery_timer = 0.0; _send_discovery_beacon()

@rpc("any_peer", "unreliable", "call_remote")
func _net_transform(pos: Vector3, yaw: float) -> void:
    var sender := multiplayer.get_remote_sender_id()
    if sender == 0 or sender == multiplayer.get_unique_id(): return
    if not remote_players.has(sender): _spawn_remote(sender, int(peer_team.get(sender, 0)))
    var body: CharacterBody3D = remote_players[sender]
    body.global_position = body.global_position.lerp(pos, 0.65); body.rotation.y = yaw

func _process_discovery(_delta: float) -> void:
    if not discovery_socket.is_bound(): discovery_socket.bind(DISCOVERY_PORT)
    while discovery_socket.get_available_packet_count() > 0:
        var data := discovery_socket.get_packet().get_string_from_utf8()
        if data.begins_with("MANSY_A_STRIKE:"):
            var host_ip := discovery_socket.get_packet_ip(); ip_edit.text = host_ip; room_status.text = "LAN ROOM FOUND: " + host_ip

func _send_discovery_beacon() -> void:
    var beacon := "MANSY_A_STRIKE:%d:%d" % [NET_PORT, team_size]
    var socket := PacketPeerUDP.new(); socket.set_broadcast_enabled(true); socket.set_dest_address("255.255.255.255", DISCOVERY_PORT); socket.put_packet(beacon.to_utf8()); socket.close()

func _show_profile() -> void:
    var text := "PROFILE / STATISTICS\n\nMatches: %d\nKills: %d\nDeaths: %d\nK/D: %.2f\n\nBest modes: TDM / Deathmatch / Bomb\nBomb Mission: OFFLINE ONLY" % [profile_matches, profile_kills, profile_deaths, float(profile_kills) / maxf(1.0, float(profile_deaths))]
    _show_overlay("PROFILE", text)

func _show_settings() -> void:
    if settings_panel and is_instance_valid(settings_panel): settings_panel.queue_free()
    settings_panel = ColorRect.new(); settings_panel.position = Vector2(360, 110); settings_panel.size = Vector2(560, 500); settings_panel.color = Color(0.03, 0.04, 0.06, 0.98); menu_root.add_child(settings_panel)
    var title := Label.new(); title.text = "SETTINGS"; title.position = Vector2(25, 20); title.add_theme_font_size_override("font_size", 26); settings_panel.add_child(title)
    var sens := HSlider.new(); sens.position = Vector2(25, 80); sens.size = Vector2(500, 40); sens.min_value = 0.5; sens.max_value = 2.0; sens.step = 0.05; sens.value = sensitivity; settings_panel.add_child(sens)
    var sl := Label.new(); sl.text = "Aim Sensitivity"; sl.position = Vector2(25, 55); settings_panel.add_child(sl)
    sens.value_changed.connect(func(v): sensitivity = v; _save_profile())
    var fps := OptionButton.new(); fps.position = Vector2(25, 150); fps.size = Vector2(220, 45); fps.add_item("30 FPS"); fps.add_item("45 FPS"); fps.add_item("60 FPS"); fps.add_item("90 FPS"); fps.selected = 2; settings_panel.add_child(fps)
    fps.item_selected.connect(func(i): Engine.max_fps = [30, 45, 60, 90][i])
    var gfx := OptionButton.new(); gfx.position = Vector2(280, 150); gfx.size = Vector2(220, 45); gfx.add_item("LOW"); gfx.add_item("MEDIUM"); gfx.add_item("HIGH"); gfx.selected = graphics_quality; settings_panel.add_child(gfx)
    gfx.item_selected.connect(func(i): graphics_quality = i; _save_profile())
    var close := _menu_button("CLOSE", Vector2(25, 225), Vector2(180, 50)); settings_panel.add_child(close); close.pressed.connect(func(): settings_panel.queue_free(); settings_panel = null)

func _show_overlay(title_text: String, body_text: String) -> void:
    var overlay := ColorRect.new(); overlay.position = Vector2(300, 100); overlay.size = Vector2(680, 520); overlay.color = Color(0.02, 0.03, 0.05, 0.98); menu_root.add_child(overlay)
    var title := Label.new(); title.text = title_text; title.position = Vector2(30, 25); title.add_theme_font_size_override("font_size", 28); overlay.add_child(title)
    var body := Label.new(); body.text = body_text; body.position = Vector2(30, 80); body.size = Vector2(620, 350); body.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART; body.add_theme_font_size_override("font_size", 18); overlay.add_child(body)
    var close := _menu_button("CLOSE", Vector2(30, 440), Vector2(180, 50)); overlay.add_child(close); close.pressed.connect(func(): overlay.queue_free())

func _load_profile() -> void:
    var cfg := ConfigFile.new()
    if cfg.load(profile_path) == OK:
        profile_kills = int(cfg.get_value("stats", "kills", 0)); profile_deaths = int(cfg.get_value("stats", "deaths", 0)); profile_matches = int(cfg.get_value("stats", "matches", 0))
        sensitivity = float(cfg.get_value("settings", "sensitivity", 1.0)); graphics_quality = int(cfg.get_value("settings", "graphics", 1))

func _save_profile() -> void:
    var cfg := ConfigFile.new(); cfg.set_value("stats", "kills", profile_kills); cfg.set_value("stats", "deaths", profile_deaths); cfg.set_value("stats", "matches", profile_matches); cfg.set_value("settings", "sensitivity", sensitivity); cfg.set_value("settings", "graphics", graphics_quality); cfg.save(profile_path)

func _update_profile_label() -> void:
    if profile_label:
        profile_label.text = "PROFILE  •  %d MATCHES\nKILLS %d  •  DEATHS %d" % [profile_matches, profile_kills, profile_deaths]
