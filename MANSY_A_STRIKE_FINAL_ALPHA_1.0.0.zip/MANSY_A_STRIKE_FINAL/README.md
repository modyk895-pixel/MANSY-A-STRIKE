# MANSY A STRIKE — Mobile FPS

Version: 1.0.0-alpha
Target: Android / Landscape 16:9
Renderer: Godot 4.x GL Compatibility

## Implemented
- Offline: TDM, Deathmatch, Training, Bomb Mission
- Offline team sizes: 1v1 through 5v5
- AI difficulty: Easy / Normal / Hard / Elite
- Bomb Mission: A / B / C, attacker/defender logic, planting, defuse AI, rounds
- Mobile controls: joystick, aim, fire, reload, jump, crouch, weapon switching, pause
- Weapons: Assault Rifle, SMG, Shotgun, Sniper, Pistol, Grenade
- Health, armor, respawn, scoring, kill feed, profile statistics
- Hotspot/LAN: TDM and Deathmatch only; Bomb Mission is blocked in LAN
- LAN player transform replication and host-authoritative hit/damage flow
- Settings: sensitivity, FPS cap, graphics preference
- Landscape lock and 16:9 UI layout

## Important
This package is the complete source/alpha build project. It is not an APK by itself.
The environment used to prepare this package does not contain the Godot editor/export templates or Android SDK, so an APK cannot honestly be claimed as tested here.

## Android export
1. Open the project in Godot 4.x.
2. Install Android export templates and configure the Android SDK/JDK.
3. Select Project > Export > Android.
4. Build a debug APK for device testing.
5. Test offline modes first, then test Hotspot/LAN on two or more Android devices.

## Size target
No large third-party asset packs are bundled. The source package is intentionally lightweight; final APK/AAB size depends on export templates, compression, and any additional assets added later.

## Bomb Mission rules
Bomb Mission is OFFLINE ONLY. Blue attacks and carries the bomb. Red defends A/B/C and can defuse through AI behavior. The local player cannot incorrectly defuse as the attacking side.
